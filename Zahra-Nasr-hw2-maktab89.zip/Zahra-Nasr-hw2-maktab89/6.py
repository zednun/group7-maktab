dict ={}
A = input("input please")
for i in A:
    if i in dict:
        dict[i] += 1
    else:
        dict[i] = 1
print(dict)

