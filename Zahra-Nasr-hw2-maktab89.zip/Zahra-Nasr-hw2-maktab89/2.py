from functools import reduce

A = []
n = int(input("input the size please"))
for i in range(n):
    num = int(input())
    A.append(num)
def multiply(list):
    return reduce(lambda a, b: a * b, list)

print(multiply(A))
