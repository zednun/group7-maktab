def convert_c_to_f(c_degree):
    return c_degree * 1.8 + 32

my_list = []
n = int(input("input the size please"))
for i in range(n):
    num = int(input())
    my_list.append(num)
print(list(map(convert_c_to_f, my_list)))
