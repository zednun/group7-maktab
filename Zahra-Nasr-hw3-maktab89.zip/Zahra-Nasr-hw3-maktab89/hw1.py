import time

def count_time(func):
    def wrapper(n):
        starting_time = time.time()
        result = func(n)
        end_time = time.time()
        differ = end_time - starting_time
        print(f'calculated time for func : {differ}')
        return result
    return wrapper

@count_time
def non_cache_fibo(n):
    def fibonacci(n):
        if n == 0:
            return 0
        elif n == 1:
            return 1
        return fibonacci(n - 1) + fibonacci(n - 2)
    return fibonacci(n)


@count_time
def cache_fibo(n):
    def fib(n):
        fib_cache = {1: 1, 2: 1}
        if n in fib_cache:
            return fib_cache[n]

        fib_cache[n] = fib(n - 2) + fib(n - 1)
        return fib_cache[n]
    return fib

@count_time
def cache_factorial(n):
    def factorial(n):
        fib_cache = {0: 1, 1: 1}
        if n in fib_cache:
            return cache_factorial[n]

        return n * cache_factorial(n-1)
    return factorial

@count_time
def non_cache_factorial(n):
    def factorial(n):
        if n == 0 or n == 1:
            return 1
        else:
            return n * factorial(n-1)
    return factorial

non_cache_fibo(int(input("non-cache fibo: enter your number :")))
print('*' * 30)
cache_fibo(int(input("cache fibo: enter your number :")))
print('*' * 30)
non_cache_factorial(int(input("non_cache_factorial: enter your number :")))
print('*' * 30)
cache_factorial(int(input("cache_factorial: enter your number :")))




