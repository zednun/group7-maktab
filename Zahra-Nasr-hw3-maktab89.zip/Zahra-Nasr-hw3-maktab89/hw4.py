import string

with open("iran.txt", "r") as file:
    x = file.read()

signs = (".", ":", ";", "?", "!", ",")
for i in signs:
    if i in x:
        x = " ".join(x.split(i))
x = set(x.split())
result = (filter(lambda i: i[0] in string.ascii_uppercase, x))

with open("iran1.txt", "w") as file:
    for i in result:
        file.write(f"{i} \n")
