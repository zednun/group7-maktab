
def _range(start: int, end: int, step: int = 1):
    try:
        num = []
        i = start
        if step > 0:
            while i < end:
                num.append(i)
                i += 1
            yield num[:end:step]
        else:
            while end < i:
                num.append(i)
                i -= 1
            yield num[::-step]

    except TypeError:
         print("please input integer")

start, end, step = input("input start, end, step").split()
for i in _range(int(start), int(end), int(step)):
    print(i)


