class Person:
    def __int__(self, name, email, gender):
        self.name = name
        self.email = email
        self.gender = gender

class Writer(Person):
    def __int__(self, writing_code, genre):
        super().__init__()
        self.writing_code = writing_code
        self.genre = genre

class Poetry(Person):
    def __init__(self, genre):
        super().__init__()
        self.genre = genre

class Researcher(Person):
    def __init__(self, major, university):
        super().__init__()
        self.major = major
        self.university = university




class Piece(Person):
    def __int__(self, piece_name):
        self.piece_name = piece_name
        super().__init__()
        # self.person = Person(name, email, gender)

class Book(Piece):
    def __init__(self, book_name, price, number, ISBN, publisher):
        super().__init__()
        self.book_name = book_name
        self.price = price
        self.number = abs(number)
        self.isbn = ISBN
        self.publisher = publisher

class Poet(Piece):
    def __init__(self, literary_format, outer):
        super().__init__()
        if isinstance(outer, Poetry):
            self.outer = outer
        else:
            raise TypeError
        self.literary_format = literary_format

class Article(Piece):
    def __init__(self, magazine_name, publish_year):
        super().__init__()
        self.magazine_name = magazine_name
        self.publish_year = publish_year



