
import time

class Birthday:
    def __init__(self, year, month, day, hour):
        self.year = year
        self.month = month
        self.day = day
        self.hour = hour

    def calculate_age(self):
        self.now = time.localtime()
        year_Age = self.now.tm_year - self.year
        hour_age = year_Age * 12 * 30 * 24
        return year_Age, hour_age

    def calc_ramaining_toBirthDay(self):
        if self.now.tm_mon > self.month:
            rem_mon = (12 - self.now.tm_mon) + self.month
        else:
            rem_mon = self.month - self.now.tm_mon

        if self.day > self.now.tm_mday:
            rem_day = (30 + self.now.tm_mday) - self.day
            rem_mon -= 1
        else:
            rem_day = self.now.tm_mday - self.day
        return rem_mon, rem_day


zahra = Birthday(1997, 9, 20, 2)
print(zahra.calculate_age())
print(zahra.calc_ramaining_toBirthDay())
