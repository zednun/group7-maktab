vowels = ('a', 'e', 'i', 'o', 'u', 'A', 'E', 'I', 'O', 'U')
text = input("input please: ")
my_list = []

i = 0
length = len(text)
while i < length:
    if text[i] in vowels:
        my_list.append('.')
    elif text[i].isupper():
        my_list.append(text[i].lower())
    elif text[i].islower():
        my_list.append(text[i].upper())

    i += 1

result = "".join(my_list)
print(result)
