list = []
result = []
n = int(input("input a size please"))
for i in range(n):
    list.append(input())
my_set = set(list)

for i in my_set:
    result.append(i)
print(result)
