for i in range(5, 0, -1):
    j = i
    while j > 0:
        print(j, end='')
        j -= 1
    print()

