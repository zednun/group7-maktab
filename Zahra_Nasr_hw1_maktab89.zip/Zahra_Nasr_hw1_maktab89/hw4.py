num = int(input("please input a number: "))
result = 0
dev = 0
while num > 0:
    dev = num % 10
    result = result * 10 + dev
    num = int(num / 10)

print(result)
