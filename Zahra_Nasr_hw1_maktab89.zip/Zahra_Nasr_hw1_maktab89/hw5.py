user = input("input user please")
password = input("input password please")

if user == 'admin':
    if password == 'admin':
        print('Welcome on Admin')
    else:
        print('Wrong')
else:
    print('Hello', user)
