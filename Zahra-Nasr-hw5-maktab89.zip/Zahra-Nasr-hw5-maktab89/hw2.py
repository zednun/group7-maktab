class Add():
    def __init__(self):
        self.sum = 0
        
    def __call__(self, *args):
        for arg in args:
            self.sum += arg
        return self.sum


numbers = Add()

print(numbers(int(5), int(10.5), int(30)))
