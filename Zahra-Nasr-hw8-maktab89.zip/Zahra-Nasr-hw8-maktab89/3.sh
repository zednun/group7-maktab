#! /bin/bash

read -p "enter a directory: " text
echo " number of directory is: "
find . -type d | wc -l
echo " number of files are: "
find . -type f | wc -l
