#! /bin/bash

while true
do
read number
if [ $number == exit ]; then
break
else
echo $((number ** 2))
fi
done
