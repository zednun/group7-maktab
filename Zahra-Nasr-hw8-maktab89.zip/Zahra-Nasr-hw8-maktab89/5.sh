#! /bin/bash

read -p "enter a directory" text
if [ ! -d $text ]
then
mkdir $text
fi

