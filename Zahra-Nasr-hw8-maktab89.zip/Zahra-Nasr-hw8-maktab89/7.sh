#! /bin/bash

read -p "enter a directory: " url

curl -o file.jpg $url
echo $url >> log.txt

